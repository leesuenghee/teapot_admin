const express = require("express");
const cors = require("cors");
const app = express();
const PORT = process.env.port || 8000;
const mysql = require("mysql");

let corsOptions = {
    origin: "*", //모든 출처
    credentials: true,
};
app.use(cors(corsOptions));

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "1234",
    database: "bbs",
});

db.connect();

app.get("/list", (req, res) => {
    const sqlQuery =
        "SELECT BOARD_ID, BOARD_TITLE, REGISTER_ID, DATE_FORMAT(REGISTER_DATE,'%Y-%m-%d') AS REGISTER_DATE FROM BOARD";
    db.query(sqlQuery, (err, result) => {
        res.send(result);
    });
});

app.listen(PORT, () => {
    console.log(`running on port ${PORT}`);
});
